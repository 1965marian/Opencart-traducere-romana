<?php
// Text
$_['text_title']				= 'Card de credit/debit (Procesare securizată asigurată de PayPal)';
$_['text_wait']					= 'Te rugăm să aștepți!';
$_['text_credit_card']			= 'Detalii Credit Card';
$_['text_loading']				= 'Se încarcă..';

// Entry
$_['entry_cc_type']				= 'Tipul cardului:';
$_['entry_cc_number']			= 'Numărul cardului:';
$_['entry_cc_start_date']		= 'Card Valid Din Data:';
$_['entry_cc_expire_date']		= 'Data de expirare a cardului:';
$_['entry_cc_cvv2']				= 'Numărul de securitate al cardului (CVV2):';
$_['entry_cc_issue']			= 'Numărul de emitere a cardului:';

// Help
$_['help_start_date']			= '(dacă există)';
$_['help_issue']				= '(doar pentru cardurile Maestro si Solo)';