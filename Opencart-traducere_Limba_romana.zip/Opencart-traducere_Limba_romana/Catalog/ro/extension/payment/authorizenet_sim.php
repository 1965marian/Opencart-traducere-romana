<?php
// Text
$_['text_title'] = 'Card de credit / debit (Authorize.Net)';