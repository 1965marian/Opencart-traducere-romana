<?php
// Text
$_['text_title']				= 'Instrucţiuni pentru plata cu CEC / Mandat poștal';
$_['text_instruction']			= 'CEC Bancar / Mandat poștal';
$_['text_payable']				= 'Plată Către: ';
$_['text_address']				= 'Trimite la: ';
$_['text_payment']				= 'Comanda va fi livrată doar după confirmarea plății.';