<?php
// Text
$_['text_title']	= 'Plătește prin PayPal';
$_['text_testmode']	= 'Avertisment: Metoda de plată este în \'Sandbox Mode\'. Din contul tău nu va fii perceput totalul.';
$_['text_total']	= 'Livrare, Desfacere, Discounturi & Taxe';