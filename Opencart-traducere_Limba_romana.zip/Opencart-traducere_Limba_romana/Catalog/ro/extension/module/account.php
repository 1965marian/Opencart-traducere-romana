<?php
// Heading
$_['heading_title']    = 'Contul meu';

// Text
$_['text_register']    = 'Înregistrează-te';
$_['text_login']       = 'Autentifică-te';
$_['text_logout']      = 'Ieșire din cont';
$_['text_forgotten']   = 'Am uitat parola';
$_['text_account']     = 'Contul meu';
$_['text_edit']        = 'Editează informațiile contului';
$_['text_password']    = 'Schimbă parola';
$_['text_address']     = 'Adresele mele';
$_['text_wishlist']    = 'Wish List';
$_['text_order']       = 'Istoric Comenzi';
$_['text_download']    = 'Descărcări';
$_['text_reward']      = 'Puncte de recompensă';
$_['text_return']      = 'Returnări';
$_['text_transaction'] = 'Tranzacții';
$_['text_newsletter']  = 'Newsletter';
$_['text_recurring']   = 'Plăți periodice (abonamente)';