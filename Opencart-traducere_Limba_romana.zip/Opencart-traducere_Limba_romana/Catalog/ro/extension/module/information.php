<?php
// Heading
$_['heading_title'] = 'Informaţii';

// Text
$_['text_contact']  = 'Contactaţi-ne';
$_['text_sitemap']  = 'Harta sitului';