<?php
// Heading
$_['heading_title'] = 'Filtre de căutare';