<?php
// Heading
$_['heading_title'] = 'Recent adăugate';

// Text
$_['text_tax']      = 'Fără TVA:';