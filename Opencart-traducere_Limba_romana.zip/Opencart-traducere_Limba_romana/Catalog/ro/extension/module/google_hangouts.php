<?php
// Heading
$_['heading_title']  = 'Asistența Online';