<?php
// Heading
$_['heading_title'] = 'Recomandări';

// Text
$_['text_tax']      = 'Fără TVA:';