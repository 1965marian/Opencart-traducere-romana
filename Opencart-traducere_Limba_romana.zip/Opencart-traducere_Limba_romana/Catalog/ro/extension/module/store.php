<?php
// Heading
$_['heading_title'] = 'Alege un magazin';

// Text
$_['text_default']  = 'Implicit';
$_['text_store']    = 'Alege magazinul pe care dorești să-l vizitezi.';