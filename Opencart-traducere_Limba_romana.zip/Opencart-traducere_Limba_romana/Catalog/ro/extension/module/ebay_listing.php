<?php
$_['heading_title'] = 'Pe magazinul nostru eBay';