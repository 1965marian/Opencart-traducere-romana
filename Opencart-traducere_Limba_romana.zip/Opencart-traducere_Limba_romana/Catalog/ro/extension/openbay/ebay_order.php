<?php
// Text
$_['text_total_shipping']		= 'Livrare';
$_['text_total_discount']		= 'Discount';
$_['text_total_tax']			= 'Taxa';
$_['text_total_sub']			= 'Subtotal';
$_['text_total']				= 'Total';