<?php
// Text
$_['text_title']       = 'Livrare cu taxă fixă';
$_['text_description'] = 'Livrare cu taxă fixă';