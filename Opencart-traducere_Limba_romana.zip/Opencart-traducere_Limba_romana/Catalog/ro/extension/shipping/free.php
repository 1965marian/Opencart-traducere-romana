<?php
// Text
$_['text_title']       = 'Livrare Gratuită';
$_['text_description'] = 'Livrare Gratuită';