<?php
// Text
$_['text_title']       = 'Ridică din magazin';
$_['text_description'] = 'Ridică din magazin';