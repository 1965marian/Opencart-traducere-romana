<?php
// Heading
$_['heading_title'] = 'Cod de verificare';

// Entry
$_['entry_captcha'] = 'Introdul codul de verificare';

// Error
$_['error_captcha'] = 'Codul de verificare este incorect!';
