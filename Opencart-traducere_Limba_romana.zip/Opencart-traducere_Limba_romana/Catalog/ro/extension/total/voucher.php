<?php
// Heading
$_['heading_title'] = 'Aplică un voucher cadou';

// Text
$_['text_voucher'] = 'Voucher cadou(%s)';
$_['text_success']  = 'Succes: Voucherul cadou a fost aplicat!';

// Entry
$_['entry_voucher'] = 'Introdu codul voucherului cadou aici';

// Error
$_['error_voucher'] = 'Atenție: Voucherul cadou este invalid sau a fost deja folosit!';
$_['error_empty']   = 'Atenție: Introdu codul voucherului cadou!';