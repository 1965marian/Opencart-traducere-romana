<?php
$_['text_low_order_fee'] = 'Comision pentru comandă mică';