<?php
$_['text_credit']   = 'Credit Magazin:';
$_['text_order_id'] = 'ID Comandă: #%s';