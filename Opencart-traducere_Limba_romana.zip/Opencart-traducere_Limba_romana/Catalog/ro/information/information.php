<?php
// Text
$_['text_error'] = 'Pagina de informații nu a fost gasită!';