<?php
// Heading
$_['heading_title']    = 'Harta Sitului';

// Text
$_['text_special']     = 'Oferte Speciale';
$_['text_account']     = 'Contul Meu';
$_['text_edit']        = 'Informații cont';
$_['text_password']    = 'Parolă';
$_['text_address']     = 'Adrese';
$_['text_history']     = 'Istoric comenzi';
$_['text_download']    = 'Descărcări';
$_['text_cart']        = 'Coș de cumpărături';
$_['text_checkout']    = 'Finalizare comandă';
$_['text_search']      = 'Căutare';
$_['text_information'] = 'Informații';
$_['text_contact']     = 'Contactați-ne';