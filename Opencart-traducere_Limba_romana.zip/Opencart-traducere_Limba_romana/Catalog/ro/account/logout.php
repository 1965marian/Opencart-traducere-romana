<?php
// Heading
$_['heading_title'] = 'Ieşire din cont';

// Text
$_['text_message']  = '<p>Ai ieşit din contul tău. Puteţi părăsi calculatorul în siguranţă.</p><p>Coşul de cumpărături a fost salvat, Produsele din coş vor fi restaurate la următoarea autentificare.</p>';
$_['text_account']  = 'Cont';
$_['text_logout']   = 'Ieşire din cont';