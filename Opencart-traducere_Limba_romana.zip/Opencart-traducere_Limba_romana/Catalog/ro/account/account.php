<?php
// Heading
$_['heading_title']      = 'Contul Meu';

// Text
$_['text_account']       = 'Cont';
$_['text_my_account']    = 'Contul Meu';
$_['text_my_orders']     = 'Comenzile Mele';
$_['text_my_newsletter'] = 'Newsletter';
$_['text_my_affiliate']  = 'Contul meu de afiliat';
$_['text_edit']          = 'Editează informațiile contului';
$_['text_password']      = 'Schimbă parola';
$_['text_address']       = 'Modifică adresele';
$_['text_credit_card']   = 'Administrează cardurile de credit stocate';
$_['text_wishlist']      = 'Modifică Wishlist-ul';
$_['text_order']         = 'Vezi istoricul comenzilor';
$_['text_download']      = 'Descărcări';
$_['text_reward']        = 'Puncte de recompensă';
$_['text_return']        = 'Cereri de returnare produse';
$_['text_transaction']   = 'Transacții (Credit magazin)';
$_['text_newsletter']    = 'Abonare / Dezabonare newsletter';
$_['text_recurring']     = 'Plați periodice(abonamente)';
$_['text_transactions']  = 'Tranzacții (Credit magazin)';
$_['text_affiliate_add']  = 'Inregistreaza un cont de afiliat';
$_['text_affiliate_edit'] = 'Editeaza informatiile contului de afiliat';
$_['text_tracking']       = 'Cod de tracking afiliat';