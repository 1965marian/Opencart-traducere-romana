<?php
// Heading
$_['heading_title']    = 'Tracking Afiliati';

// Text
$_['text_account']     = 'Cont';
$_['text_description'] = 'Pentru a te asigura ca vei fi platit pentru vizitatorii pe care ii trimiti pe situl nostru, trebuie sa urmarim accesarile cu un cod de tracking in url.Foloseste uneltele de mai jos pentru a crea linkuri catre situl %s .';

// Entry
$_['entry_code']       = 'Codul tau de tracking';
$_['entry_generator']  = 'Generator linkuri de tracking';
$_['entry_link']       = 'Link de tracking';

// Help
$_['help_generator']  = 'Scrie numele produsului pentru care doresti link';