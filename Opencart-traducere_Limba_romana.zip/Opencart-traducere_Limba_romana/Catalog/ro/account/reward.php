<?php
// Heading
$_['heading_title']      = 'Puncte de recompensă';

// Column
$_['column_date_added']  = 'Data adăugării';
$_['column_description'] = 'Descriere';
$_['column_points']      = 'Puncte';

// Text
$_['text_account']       = 'Cont';
$_['text_reward']        = 'Puncte de recompensă';
$_['text_total']         = 'Numărul total de puncte de recompensă este:';
$_['text_empty']         = 'Nu aveţi niciun punct de recompensă!';