<?php
// Heading
$_['heading_title']      = 'Tranzacţii (Credit magazin)';

// Column
$_['column_date_added']  = 'Data adăugării';
$_['column_description'] = 'Descriere';
$_['column_amount']      = 'Suma (%s)';

// Text
$_['text_account']       = 'Cont';
$_['text_transaction']   = 'Tranzacţii';
$_['text_total']         = 'Balanţa ta curentă este:';
$_['text_empty']         = 'Nu ai nicio tranzacţie!';