<?php
// Text
$_['text_subject']      = '%s - Comanda %s';
$_['text_received']     = 'O noua comanda';
$_['text_order_id']     = 'ID Comandă:';
$_['text_date_added']   = 'Data adăugării:';
$_['text_order_status'] = 'Statusul comenzii:';
$_['text_product']      = 'Produse';
$_['text_total']        = 'Totaluri';
$_['text_comment']      = 'Comentarii:';
