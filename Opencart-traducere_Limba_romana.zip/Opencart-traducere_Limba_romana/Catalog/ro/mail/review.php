<?php
// Text
$_['text_subject']	= '%s - O noua opinie despre produs';
$_['text_waiting']	= 'O nouă opinie despre produs a fost adăugată si așteaptă aprobarea.';
$_['text_product']	= 'Produs: %s';
$_['text_reviewer']	= 'Utilizatorul: %s';
$_['text_rating']	= 'Nota: %s';
$_['text_review']	= 'Textul opiniei:';