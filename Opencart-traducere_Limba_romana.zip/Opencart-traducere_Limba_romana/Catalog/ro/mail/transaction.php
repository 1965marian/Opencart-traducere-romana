<?php
// Text
$_['text_subject']  = '%s - Comision Afiliat';
$_['text_received'] = 'Ai primit un comision de la programul de afiliati %s';
$_['text_amount']   = 'Ai primit:';
$_['text_total']    = 'Comisionul total este acum:';