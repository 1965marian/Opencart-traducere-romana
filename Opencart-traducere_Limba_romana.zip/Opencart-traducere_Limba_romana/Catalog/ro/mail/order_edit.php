<?php
// Text
$_['text_subject']      = '%s - Actualizare Comanda %s';
$_['text_order_id']     = 'ID Comandă:';
$_['text_date_added']   = 'Data adăugării:';
$_['text_order_status'] = 'Comanda ta a fost actualizată cu următorul status:';
$_['text_comment']      = 'Comentarii:';
$_['text_link']         = 'Pentru a viziona comanda ta, fă click pe următorul link:';
$_['text_footer']       = 'Te rugăm să răspunzi la acest e-mail dacă ai vreo întrebare.';