<?php
// Text
$_['text_success']     = 'Succes: Cuponul tău de discount a fost aplicat!';

// Error
$_['error_permission'] = 'Atenție: Nu ai permisiunile necesare pentru a accesa API-ul!';
$_['error_coupon']     = 'Atentie: Cuponul este ori invalid ori expirat ori a fost deja folosit la maxim!';