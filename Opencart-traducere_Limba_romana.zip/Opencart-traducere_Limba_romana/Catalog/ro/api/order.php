<?php
// Text
$_['text_success']           = 'Comanda a fost modificată cu success';

// Error
$_['error_permission']       = 'Atenție: Nu ai permisiunile necesare pentru a accesa API-ul!';
$_['error_customer']         = 'Lipsesc detaliile despre client!';
$_['error_payment_address']  = 'Lipsește adresa de plată!';
$_['error_payment_method']   = 'Lipsește metoda de plată!';
$_['error_no_payment']       = 'Avertisment: Nu sunt disponibile metode de plata!';
$_['error_shipping_address'] = 'Lipsește adresa de livrare!';
$_['error_shipping_method']  = 'Lipsește metoda de livrare!';
$_['error_no_shipping']      = 'Avertisment: Nu sunt disponibile metode de livrare!';
$_['error_stock']            = 'Produsele marcate cu *** nu sunt disponibile în cantitatea dorită sau nu sunt în stoc deloc!';
$_['error_minimum']          = 'Cantitatea minima de %s ce poate fi comandată este %s!';
$_['error_not_found']        = 'Eroare: Comanda nu a fost găsită!';