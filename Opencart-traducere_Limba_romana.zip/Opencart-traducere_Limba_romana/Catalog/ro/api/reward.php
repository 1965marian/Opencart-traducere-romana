<?php
// Text
$_['text_success']     = 'Succes: Punctele de recompensă au fost aplicate!';

// Error
$_['error_permission'] = 'Atenție: Nu ai permisiunile necesare pentru a accesa API-ul!';
$_['error_reward']     = 'Eroare: Introduceți numărul de puncte de recompensă ce vor fi folosite!';
$_['error_points']     = 'Eroare: Nu ai %s puncte de recompensă!';
$_['error_maximum']    = 'Eroare: Maximul de puncte de recompensă ce poate fi aplicat este %s!';