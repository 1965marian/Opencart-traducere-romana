<?php
// Text
$_['text_success']     = 'Succes: Valuta a fost schimbată!';

// Error
$_['error_permission'] = 'Avertisment: Nu ai permisiunile necesare pentru accesarea API-uli!';
$_['error_currency']   = 'Avertisment: Codul valutei este invalid!';