<?php
// Text
$_['text_success']       = 'Ai modificat clienții cu success';

// Error
$_['error_permission']   = 'Atenție: Nu ai permisiunile necesare pentru a accesa API-ul!';
$_['error_firstname']    = 'Prenumele trebuie să conțină între 1 și 32 de caractere!';
$_['error_lastname']     = 'Numele trebuie să conțină între 1 și 32 de caractere!';
$_['error_email']        = 'Adresa de e-mail nu este validă!';
$_['error_telephone']    = 'Numărul de telefon trebuie să conțină între 3 și 32 de caractere!';
$_['error_custom_field'] = '%s este obligatoriu!';