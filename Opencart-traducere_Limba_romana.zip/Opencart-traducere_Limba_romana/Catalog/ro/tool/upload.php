<?php
// Text
$_['text_upload']    = 'Fișierul a fost încărcat cu succes!';

// Error
$_['error_filename'] = 'Numele fisierului trebuie să conțină între 3 și 64 de caractere!';
$_['error_filetype'] = 'Tip de fișier invalid!';
$_['error_upload']   = 'Trebuie să selectați un fișier!';
