<?php
// Text
$_['text_items']    = '%s produs(e) - %s';
$_['text_empty']    = 'Coșul este gol!';
$_['text_cart']     = 'Vezi Coșul';
$_['text_checkout'] = 'Finalizează comanda';
$_['text_recurring']  = 'Abonament';