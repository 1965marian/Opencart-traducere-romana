<?php
// Text
$_['text_all'] = 'Afiseaza mai multe ';