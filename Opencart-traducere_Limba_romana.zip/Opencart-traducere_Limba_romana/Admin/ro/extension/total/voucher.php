<?php
// Heading
$_['heading_title']    = 'Voucher Cadou';

// Text
$_['text_total']       = 'Totalul Comenzii';
$_['text_success']     = 'Succes: Ai modificat totalul voucher cadou!';
$_['text_edit']        = 'Editează totalul Voucher Cadou';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Ordine Sortare';

// Error
$_['error_permission'] = 'Eroare: Nu ai permisiunile necesare pentru a modifica această pagină. Contactează administratorul pentru asistență. Daca ești administrator mergi in admin la grupuri de utilizatori și actualizează permisiunile!';