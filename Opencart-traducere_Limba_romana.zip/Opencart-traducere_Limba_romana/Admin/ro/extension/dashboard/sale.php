<?php
// Heading
$_['heading_title'] = 'Vânzări Totale';

// Text
$_['text_view']     = 'Vezi mai mult...';