<?php
// Heading
$_['heading_title']     = 'Ultimele Comenzi';

// Column
$_['column_order_id']   = 'ID Comandă';
$_['column_customer']   = 'Client';
$_['column_status']     = 'Status';
$_['column_total']      = 'Total';
$_['column_date_added'] = 'Data Adăugării';
$_['column_action']     = 'Acțiune';