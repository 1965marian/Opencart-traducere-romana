<?php
// Heading
$_['heading_title'] = 'Clienți Online';

// Text
$_['text_view']     = 'Vezi mai mult...';