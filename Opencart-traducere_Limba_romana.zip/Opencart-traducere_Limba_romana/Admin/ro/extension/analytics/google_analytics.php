<?php
$_['heading_title']    = 'Google Analytics';

// Text
$_['text_analytics']   = 'Analytics';
$_['text_success']	   = 'Succes: Ai modificat Google Analytics!';
$_['text_edit']        = 'Editează Google Analytics';
$_['text_signup']      = 'Autentifică-te în contul tău de <a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a> , crează un profil pentru acest site iar apoi adaugă codul obținut în următorul câmp.';

// Entry
$_['entry_code']       = 'Codul Google Analytics';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Avertizare: Nu ai permisiunea să modifici Google Analytics!';
$_['error_code']	   = 'Cod obligatoriu!';
