<?php
// Heading
$_['heading_title']    = 'Cont';

$_['text_module']      = 'Module';
$_['text_success']     = 'Succes: Ai modificat modulul cont!';
$_['text_edit']        = 'Editează modulul Cont';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Eroare: Nu ai permisiunile necesare pentru a modifica această pagină. Contactează administratorul pentru asistență. Daca ești administrator mergi in admin la grupuri de utilizatori și actualizează permisiunile!';