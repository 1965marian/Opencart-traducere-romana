<?php
// Heading
$_['heading_title']    = 'Marketing';

// Text
$_['text_success']     = 'Succes: Ai modificat extensiile de marketing!';
$_['text_list']        = 'Lista';

// Column
$_['column_name']      = 'Nume extensie';
$_['column_status']    = 'Status';
$_['column_action']    = 'Actiune';

// Error
$_['error_permission'] = 'Atentie: Nu ai permisiunea sa modifici extensiile de marketing!';