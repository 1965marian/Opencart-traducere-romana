<?php
// Heading
$_['heading_title']     = 'Diverse';

// Text
$_['text_success']      = 'Succes: Ai modificat extensiile!';
$_['text_list']         = 'Lista';

// Column
$_['column_name']       = 'Nume';
$_['column_status']     = 'Status';
$_['column_action']     = 'Actiune';

// Error
$_['error_permission'] = 'Atentie: Nu ai permisiunile necesare pentru a putea modifica aceasta pagina!';