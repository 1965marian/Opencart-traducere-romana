<?php
// Heading
$_['heading_title']    = 'Extensii pentru analizarea traficului';

// Text
$_['text_success']     = 'Succes: Ai modificat Extensiile de analizare trafic!';
$_['text_list']        = 'Lista Extensiilor';

// Column
$_['column_name']      = 'Nume Analytics';
$_['column_status']    = 'Status';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Avertizare: Nu ai permisiunea să modifici Extensiile de analizare trafic !';
