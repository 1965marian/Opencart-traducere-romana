<?php
// Heading
$_['heading_title']    = 'Teme';

// Text
$_['text_success']     = 'Succes: Ai modificat temele!';
$_['text_list']        = 'Listă Teme';

// Column
$_['column_name']      = 'Nume tema';
$_['column_status']    = 'Status';
$_['column_action']    = 'Acţiune';

// Error
$_['error_permission'] = 'Eroare: Nu ai permisiunile necesare pentru a modifica această pagină. Contactează administratorul pentru asistență. Daca ești administrator mergi in admin la grupuri de utilizatori și actualizează permisiunile!';