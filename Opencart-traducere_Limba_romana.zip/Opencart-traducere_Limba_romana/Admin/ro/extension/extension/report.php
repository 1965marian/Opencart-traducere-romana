<?php
// Heading
$_['heading_title']     = 'Rapoarte';

// Text
$_['text_success']      = 'Succes: Ai modificat extensiile de tip raport!';
$_['text_list']         = 'Lista rapoarte';

// Column
$_['column_name']       = 'Nume';
$_['column_status']     = 'Status';
$_['column_sort_order'] = 'Numar de ordine';
$_['column_action']     = 'Actiune';

// Error
$_['error_permission'] = 'Atentie: Nu ai permisiunile necesare pentru a putea modifica aceasta pagina!';