<?php
// Heading
$_['heading_title']    = 'Feed-uri';

// Text
$_['text_success']     = 'Succes: Ai modificat feed-urile!';
$_['text_list']        = 'Listă Feed-uri';

// Column
$_['column_name']      = 'Nume Feed';
$_['column_status']    = 'Status';
$_['column_action']    = 'Acţiune';

// Error
$_['error_permission'] = 'Avertisment: Nu ai permisiunea de a modifica feed-urile!';