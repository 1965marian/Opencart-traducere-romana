<?php
// Heading
$_['heading_title']		 = 'Gratuit';

// Text
$_['text_payment']		 = 'Plată';
$_['text_success']		 = 'Succes: Ai modificat modulul de plată Checkout gratuit!';
$_['text_edit']          = 'Editează Checkout gratuit';

// Entry
$_['entry_order_status'] = 'Statusul comenzii';
$_['entry_status']		 = 'Status';
$_['entry_sort_order']	 = 'Ordine Sortare';

// Error
$_['error_permission']	  = 'Eroare: Nu ai permisiunile necesare pentru a modifica această pagină. Contactează administratorul pentru asistență. Daca ești administrator mergi in admin la grupuri de utilizatori și actualizează permisiunile!';