<?php
// Heading
$_['heading_title']    = 'Raport Produse Vizualizate';

// Text
$_['text_extension']               = 'Extensii';
$_['text_success']                 = 'Succes: Ai modificat raportul!';
$_['text_filter']                  = 'Filtrare';

// Column

$_['column_name']      = 'Nume Produs';
$_['column_model']     = 'Model';
$_['column_viewed']    = 'Vizualizat';
$_['column_percent']   = 'Procent';


// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Numar de ordine';

// Error
$_['error_permission'] = 'Atentie: Nu ai permisiunile necesare pentru a putea modifica aceasta pagina!';