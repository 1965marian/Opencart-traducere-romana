<?php
// Heading
$_['heading_title'] = 'Extensii';

// Text
$_['text_success']  = 'Succes: Ai modificat extensiile!';
$_['text_list']     = 'Lista Extensii';
$_['text_type']     = 'Alege tipul extensiei';
$_['text_filter']   = 'Filtrare';