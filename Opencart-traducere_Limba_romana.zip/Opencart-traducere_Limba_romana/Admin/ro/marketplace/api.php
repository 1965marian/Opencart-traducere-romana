<?php
// Heading
$_['heading_title']    = 'API OpenCart Marketplace';

// Text
$_['text_success']     = 'Succes: Ai modificat extensiile!';
$_['text_signup']      = 'Trebuie sa introduci datele de conectare la api-ul opencart. Acestea pot pot fi obtinute  <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link">aici</a>.';

// Entry
$_['entry_username']   = 'Username';
$_['entry_secret']     = 'Secret';

// Error
$_['error_permission'] = 'Atentie: Nu ai permisiunile necesare pentru a putea modifica aceasta pagina!';
$_['error_username']   = 'Username este obligatoriu!';
$_['error_secret']     = 'Secret este obligatoriu!';
