<?php
// header
$_['heading_title']  = 'Admin';

// Text
$_['text_heading']   = 'Admin';
$_['text_login']     = 'Introdu detaliile de autentificare.';
$_['text_forgotten'] = 'Parolă Uitată';

// Entry
$_['entry_username'] = 'Utilizator';
$_['entry_password'] = 'Parolă';

// Button
$_['button_login']   = 'Autentificare';

// Error
$_['error_login']    = 'Utilizatorul şi / sau Parola nu se potrivesc.';
$_['error_token']    = 'Jeton sesiune invalid. Loghează-te din nou.';