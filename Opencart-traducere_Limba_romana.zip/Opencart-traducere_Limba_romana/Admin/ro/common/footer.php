<?php
// Text
$_['text_footer'] 	= 'OpenCart &copy; 2009-' . date('Y') . ' Toate drepturile rezervate.<br /> Tradus de CM';
$_['text_version'] 	= 'Versiunea %s';