<?php
// Heading
$_['heading_title'] = 'Rapoarte';

// Text
$_['text_success']  = 'Succes: Ai modificat rapoartele!';
$_['text_list']     = 'Lista rapoarte';
$_['text_type']     = 'Selecteaza tipul de raport';
$_['text_filter']   = 'Filtrare';