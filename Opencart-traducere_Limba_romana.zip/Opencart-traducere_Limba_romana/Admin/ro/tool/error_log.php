<?php
// Heading
$_['heading_title']	   = 'Jurnal de Erori';

// Text
$_['text_success']	   = 'Succes: Ai șters cu succes jurnalul de erori!';
$_['text_list']        = 'Listă de erori';

// Error
$_['error_warning']	   = 'Avertisment: Jurnalul de erori %s este %s!';
$_['error_permission'] = 'Eroare: Nu ai permisiunile necesare pentru a modifica această pagină. Contactează administratorul pentru asistență. Daca ești administrator mergi in admin la grupuri de utilizatori și actualizează permisiunile!';