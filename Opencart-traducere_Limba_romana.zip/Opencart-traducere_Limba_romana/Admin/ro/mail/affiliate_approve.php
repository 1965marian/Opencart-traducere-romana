<?php
// Text
$_['text_subject']  = '%s - Contul tau de afiliat a fost activat!';
$_['text_welcome']  = 'Bine ai venit și iți mulțumim că te-ai inregistrat la %s!';
$_['text_login']    = 'Contul tău a fost creat și te poți autentifica cu adresa ta de e-mail si parola, vizitând site-ul nostru sau accesând urmatoarea adresă:';
$_['text_services'] = 'După autentificare, vei putea genera coduri de urmărire, poti urmării plata comisioanelor și vei putea edita informațiile contului tău.';
$_['text_thanks']   = 'Mulțumim,';