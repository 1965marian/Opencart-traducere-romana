<?php
// Text
$_['text_subject']  = '%s - Puncte de recompensa';
$_['text_received'] = 'Ai primit %s puncte de recompensa!';
$_['text_total']    = 'Numarul total de puncte de recompensa este acum %s.';