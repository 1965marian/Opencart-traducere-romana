<?php
// Text
$_['text_subject'] = '%s - Contul tau de afiliat nu a fost aprobat!';
$_['text_welcome'] = 'Bine ai venit și iți mulțumim că te-ai inregistrat la %s!';
$_['text_denied']  = 'Din pacate cererea ta a fost respinsa. Pentru mai multe informatii, poti contacta administratorul magazinului aici:';
$_['text_thanks']  = 'Mulțumim';