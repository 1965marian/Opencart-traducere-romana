<?php
// Text
$_['text_subject']       = '%s - Actualizare Returnare %s';
$_['text_return_id']     = 'ID-ul Returnării:';
$_['text_date_added']    = 'Data Returnării:';
$_['text_return_status'] = 'Cererea ta de returnare a fost actualizată la următorul status:';
$_['text_comment']       = 'Comentarii:';
$_['text_footer']        = 'Te rugăm să ne contactrzi pe această adresă de e-mail dacă ai întrebări.';