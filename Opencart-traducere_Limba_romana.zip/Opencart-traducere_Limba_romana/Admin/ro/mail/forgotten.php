<?php
// Text
$_['text_subject']  = '%s - Cerere resetare parola';
$_['text_greeting'] = 'A fost ceruta o nouă parolă pentru panoul de administrare al %s.';
$_['text_change']   = 'Ca să iți resetezi parola, apasă pe linkul de mai jos:';
$_['text_ip']       = 'IP-ul folosit pentru cerere a fost: %s';