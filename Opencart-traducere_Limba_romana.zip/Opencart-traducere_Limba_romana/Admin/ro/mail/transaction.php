<?php
// Text
$_['text_subject']  = '%s - Credit Afiliat';
$_['text_received'] = 'Ai primit un credit in valoare de %s!';
$_['text_total']    = 'Creditul tau total este acum %s.';
$_['text_credit']   = 'Acest credit poate fi dedus la urmatoarea ta comanda.';