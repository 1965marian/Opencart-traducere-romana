<?php
// Text
$_['text_subject'] = '%s - Contul tau a fost activat!';
$_['text_welcome'] = 'Bine ai venit. Îți mulțumim că te-ai înregistrat la %s!';
$_['text_login']   = 'Contul dumneavoastră a fost creat. Acum vă puteți autentifica folosind adresa de e-mail și parola, vizitând site-ul nostru sau la următoarea adresă:';
$_['text_service'] = 'După autentificare, vei putea accesa alte servicii, cum ar fi vizualizarea comenzilor mai vechi, poți printa facturile și vei putea edita informațiile contului tău.';
$_['text_thanks']  = 'Mulțumim,';